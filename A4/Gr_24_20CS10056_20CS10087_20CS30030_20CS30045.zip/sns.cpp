#include <iostream>
#include <vector>
#include <ctime>
#include <fstream>
#include <set>
#include <cmath>
#include <queue>
#include <map>
#include <queue>
#include <algorithm>
#include <functional>
#include <sstream>
#include <pthread.h>
#include <unistd.h>
#include <assert.h>
using namespace std;

#define NUM_NODES 37700
#define NUM_READ_POST_THREADS 10
#define NUM_PUSH_UPDATE_THREADS 25
#define SLEEP 120

class Node;
class Action;

class Action{
public:
    int user_id;
    int action_id;
    string action_type;
    time_t action_time;
    Action(){
        user_id = -1;
        action_id = -1;
        action_type = "";
        action_time = -1;
    }
    Action(const Action& a){
        user_id = a.user_id;
        action_id = a.action_id;
        action_type = a.action_type;
        action_time = a.action_time;
    }
};

// number of common neighbours for each edge
map<int, map<int, int>> commonNeighbours;
// stores node IDs for which feed queues have been updated
queue<int> feed_added[NUM_READ_POST_THREADS];

enum comparatorType {chronological, priority_based};
comparatorType get_rand_comp(){
    return (comparatorType)(rand()%2);
}
class ParentComp{
    public:
    virtual bool operator()(const Action* a, const Action* b) = 0;
};
class chronologicalComp : public ParentComp{
public:  
    bool operator()(const Action* a, const Action* b) {
        return a->action_time < b->action_time;
    }
};
class priorityComp : public ParentComp{
    int node_id;
public:
    priorityComp(int v){
        node_id = v;
    }
    bool operator()(const Action* a, const Action* b) {
        return commonNeighbours[node_id][a->user_id] < commonNeighbours[node_id][b->user_id];
    }
};
ParentComp* get_comparator(comparatorType comparator,int node_id){
    if(comparator == chronological){
        return new chronologicalComp();
    }
    else if (comparator == priority_based){
        return new priorityComp(node_id);
    }
    return NULL;
}

class Node{
    public:
    queue<Action> wall_queue;
    ParentComp* comparator_;
    std::priority_queue<Action*, vector<Action*>, std::function<bool(Action*, Action*)>> feed_queue{
    [this](Action* a, Action* b) { return comparator_->operator()(a, b); }
    };
    int action_cntr[3]; // 0:post, 1:comment, 2:like
    pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
    pthread_cond_t cv = PTHREAD_COND_INITIALIZER;
    Node(int node_id,comparatorType comparator): comparator_(get_comparator(comparator,node_id)){
        action_cntr[0] = 0;
        action_cntr[1] = 0;
        action_cntr[2] = 0;
    }
};

// Graph definition
Node* nodes[NUM_NODES];
vector<int> adj[NUM_NODES];

Action* get_action(int i){
    Action* a = new Action;
    a->user_id = i;
    a->action_time = time(NULL);
    int action = rand()%3;
    a->action_id = nodes[i]->action_cntr[action]++;
    switch(action){
        case 0:
            a->action_type = "post";
            break;
        case 1:
            a->action_type = "comment";
            break;
        case 2:
            a->action_type = "like";
            break;
    }
    return a;
}

queue<Action*> action_queue; // shared b/w userSimulator and pushUpdate
pthread_mutex_t action_queue_mutex = PTHREAD_MUTEX_INITIALIZER; // locks action_queue
pthread_mutex_t feed_queue_mutex[NUM_READ_POST_THREADS];  //locks feed_queue
pthread_mutex_t log_file_mutex = PTHREAD_MUTEX_INITIALIZER; // locks writes to log_file
pthread_cond_t push_update_cv = PTHREAD_COND_INITIALIZER;   // pushUpdate waits on this
pthread_cond_t read_post_cv[NUM_READ_POST_THREADS]; // readPost waits on this


void create_graph(string path){
    ifstream file(path);
    if(!file.is_open()) {
        cout << "Error opening file" << endl;
        exit(1);
    }
    int x=0, y=0;
    char dummy[10], c; // c consumes the comma
    file >> dummy;
    while(file >> x >> c >> y) {
        assert(x < NUM_NODES && y < NUM_NODES);
        assert(x >= 0 && y >= 0);
        adj[x].push_back(y);
        adj[y].push_back(x);

    }
    file.close();
    for(int i=0; i<NUM_NODES; i++){
        nodes[i] = new Node(i, get_rand_comp());
        // nodes[i] = new Node(i, chronological);
    }
}

void getCommonNeighbours(){
    // for every pair of neighbouring nodes in the graph,
    // find the number of common neighbours
    for(int i=0; i<NUM_NODES; i++){
        for(auto nei: adj[i]){
            int val = 0;
            if(commonNeighbours[i][nei] == 0 && commonNeighbours[nei][i] == 0){
                for(auto n1: adj[i]){
                    for(auto n2: adj[nei]){
                        if(n1 == n2) val++;
                    }
                }
            }
            else
                val = max(commonNeighbours[i][nei], commonNeighbours[nei][i]);
            commonNeighbours[i][nei] = val;
            commonNeighbours[nei][i] = val;
        }
    }
}

void* userSimulator(void* arg) {
    stringstream temp_log;
    while(1){
        temp_log << "Selected 100 random nodes\n";
        set<int> selected_nodes;
        while(selected_nodes.size() < 100){
            int node_id = rand()%NUM_NODES; 
            selected_nodes.insert(node_id);
        }
        for(auto node_id: selected_nodes){
            temp_log << "Node " << node_id << ", ";
            int degree = adj[node_id].size();
            int num_actions = 10*(1+log2(degree));
            temp_log << "Degree: " << degree << ", Num actions: " << num_actions << "\n";
            for(int i=0; i<num_actions; i++){
                Action* action = get_action(node_id);
                nodes[node_id]->wall_queue.push(*action);
                pthread_mutex_lock(&action_queue_mutex); // lock action_queue
                action_queue.push(action);         // push action to action_queue
                temp_log << "Added action " << action->action_type << " " << action->action_id << " by user " << action->user_id << " to action_queue at time " << action->action_time << "\n";
                cout<<"Added action " << action->action_type << " " << action->action_id << " by user " << action->user_id << " to action_queue at time " << action->action_time << endl;
                pthread_mutex_unlock(&action_queue_mutex);  // unlock action_queue
                pthread_cond_signal(&push_update_cv);   // signal pushUpdate
            }
            temp_log << "\n";
        }
        pthread_mutex_lock(&log_file_mutex);
        ofstream log_file;
        log_file.open("sns.log", ios::out | ios::app);
        if(!log_file.is_open()) {
            cout << "Error opening file" << endl;
            pthread_exit(NULL);
        }
        log_file << temp_log.rdbuf();
        log_file.close();
        pthread_mutex_unlock(&log_file_mutex);
        temp_log.clear();
        sleep(SLEEP);
    }  
    pthread_exit(NULL); 
}

void* pushUpdate(void* arg) {
    stringstream temp_log;
    while(1){
        pthread_mutex_lock(&action_queue_mutex); // lock action_queue
        while(action_queue.empty()){
            cout << "Waiting for signal from userSimulator" << endl;
            pthread_cond_wait(&push_update_cv, &action_queue_mutex); // wait for signal from userSimulator
        }
        assert(!action_queue.empty());
        
        Action* action = action_queue.front(); // get action from action_queue
        action_queue.pop(); // remove action from action_queue
        pthread_mutex_unlock(&action_queue_mutex); // unlock action_queue

        assert(action->user_id < NUM_NODES && action->user_id >= 0);
        for(auto node_id: adj[action->user_id]){
            int idx_to_push = node_id % NUM_READ_POST_THREADS;
            assert(idx_to_push < NUM_READ_POST_THREADS);
            assert(idx_to_push >= 0);
            Action* action_copy = new Action(*action);
            pthread_mutex_lock(&nodes[node_id]->mutex); // lock node
            nodes[node_id]->feed_queue.push(action_copy); // push action to feed_queue
            pthread_mutex_unlock(&nodes[node_id]->mutex);
            pthread_mutex_lock(&feed_queue_mutex[idx_to_push]);
            feed_added[idx_to_push].push(node_id);
            cout<<"Pushed action " << action_copy->action_type << " " << action_copy->action_id << " by user " << action_copy->user_id << " to feed_queue of node " << node_id << endl;
            pthread_mutex_unlock(&feed_queue_mutex[idx_to_push]);
            pthread_cond_signal(&read_post_cv[idx_to_push]); // signal readPost
            pthread_cond_signal(&nodes[node_id]->cv); // signal readPost
            temp_log << "Push update: action pushed to node " << node_id << "\n";
        }

        temp_log << "\n";
        delete action;

        pthread_mutex_lock(&log_file_mutex);
        ofstream log_file;
        log_file.open("sns.log", ios::out | ios::app);
        if(!log_file.is_open()) {
            cout << "Error opening file" << endl;
            pthread_exit(NULL);
        }
        log_file << temp_log.rdbuf();
        log_file.close();
        pthread_mutex_unlock(&log_file_mutex);
        temp_log.clear();
    }   
    pthread_exit(NULL);
}

void* readPost(void* arg) {
    int tid = *((int*)arg);
    while(1){
        assert(tid < NUM_READ_POST_THREADS);
        assert(tid >= 0);
        pthread_mutex_lock(&feed_queue_mutex[tid]); // lock feed_queue for all nodes corresponding to this thread
        while(feed_added[tid].empty()){
            pthread_cond_wait(&read_post_cv[tid], &feed_queue_mutex[tid]); // wait for signal from pushUpdate
        }

        assert(!feed_added[tid].empty());
        int node_id = feed_added[tid].front();
        assert(node_id % NUM_READ_POST_THREADS == tid);
        assert(node_id >= 0 && node_id < NUM_NODES);
        feed_added[tid].pop();
        pthread_mutex_unlock(&feed_queue_mutex[tid]); // unlock feed_queue for all nodes

        Action* action;
        pthread_mutex_lock(&nodes[node_id]->mutex); // unlock node
        while(nodes[node_id]->feed_queue.empty()){
            pthread_cond_wait(&nodes[node_id]->cv, &nodes[node_id]->mutex); // wait for signal from pushUpdate
        }

        assert(!nodes[node_id]->feed_queue.empty());
        
        action = nodes[node_id]->feed_queue.top(); // get action from feed_queue
        nodes[node_id]->feed_queue.pop();
        pthread_mutex_unlock(&nodes[node_id]->mutex); // lock node

        stringstream temp_log;
        char time_str[100];
        strftime(time_str, 100, "%c", localtime(&(action->action_time)));

        cout<<"Node ID: " << node_id << " reads action number " << action->action_id << " of type " << action->action_type << " by user " << action->user_id << " at time " << time_str << "\n";
        temp_log << "Node ID: " << node_id << " reads action number " << action->action_id << " of type " << action->action_type << " by user " << action->user_id << " at time " << time_str << "\n";
        delete action;

        pthread_mutex_lock(&log_file_mutex);
        ofstream log_file;
        log_file.open("sns.log", ios::out | ios::app);
        if(!log_file.is_open()) {
            cout << "Error opening file" << endl;
            pthread_exit(NULL);
        }
        log_file << temp_log.rdbuf();
        log_file.close();
        temp_log.clear();
        pthread_mutex_unlock(&log_file_mutex);
    }
    pthread_exit(NULL);
}

int main(){

    remove("sns.log");
    srand(time(NULL));
    create_graph("musae_git_edges.csv");
    cout<<"Graph created"<<endl;

    getCommonNeighbours();

    for(int i=0; i<NUM_READ_POST_THREADS; i++){
        feed_queue_mutex[i] = PTHREAD_MUTEX_INITIALIZER;
        read_post_cv[i] = PTHREAD_COND_INITIALIZER;
    }

    pthread_t userSimulatorThread;

    pthread_create(&userSimulatorThread, NULL, userSimulator, NULL);

    vector<pthread_t> readPostThreads;
    cout << "NUM READ POST THREADS = " << NUM_READ_POST_THREADS << endl;
    for(int i=0; i<NUM_READ_POST_THREADS; i++){
        pthread_t readPostThread;
        int *arg = new int;
        *arg = i;
        pthread_create(&readPostThread, NULL, readPost, (void*)arg);
        readPostThreads.push_back(readPostThread);
    }
    
    vector<pthread_t> pushUpdateThreads;
    for(int i=0; i<NUM_PUSH_UPDATE_THREADS; i++){
        pthread_t pushUpdateThread;
        pthread_create(&pushUpdateThread, NULL, pushUpdate, NULL);
        pushUpdateThreads.push_back(pushUpdateThread);
    }

    pthread_join(userSimulatorThread, NULL);
    for(int i=0; i<NUM_READ_POST_THREADS; i++){
        pthread_join(readPostThreads[i], NULL);
    }
    for(int i=0; i<NUM_PUSH_UPDATE_THREADS; i++){
        pthread_join(pushUpdateThreads[i], NULL);
    }

    pthread_mutex_destroy(&action_queue_mutex);
    pthread_mutex_destroy(&log_file_mutex);
    pthread_cond_destroy(&push_update_cv);
    
    for(int i=0; i<NUM_NODES; i++){
        pthread_mutex_destroy(&(nodes[i]->mutex));
        pthread_cond_destroy(&nodes[i]->cv);
    }
    
    for(int i=0; i<NUM_READ_POST_THREADS; i++){
        pthread_mutex_destroy(&feed_queue_mutex[i]);
        pthread_cond_destroy(&read_post_cv[i]);
    }

    return 0;
}